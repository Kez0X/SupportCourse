// importation des modules
var express = require('express');
var hash = require('pbkdf2-password')()
var path = require('path');
var session = require('express-session');
var mysql = require('mysql2');

// initialisation des variables envirronement
require('dotenv').config()
//console.log(process.env)

// initialisation de express
var app = module.exports = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'public/html'));
app.use(express.urlencoded({ extended: false }))
app.use(express.static('public/styles'))
app.use(session({
  resave: false,
  saveUninitialized: false,
  secret: 'secrett hahahahahahaha' // j'ai pas compris à quoi ce truc servait
}));

// handle des erreurs
app.use(function (req, res, next) {
  var err = req.session.error;
  var msg = req.session.success;
  delete req.session.error;
  delete req.session.success;
  res.locals.message = '';
  if (err) res.locals.message = '<p class="msg error">' + err + '</p>';
  if (msg) res.locals.message = '<p class="msg success">' + msg + '</p>';
  next();
});

// initialisation de la base de donnée MySQL
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'SiteCours',
  password: process.env.BDDpsw
});

connection.connect(function (err) {
  if (err) throw err;
  console.log("BDD connecté!");
})

// Créer un étudiant avec le mot de passe de la BDD pour l'exemple et un salt aléatoire

/* hash({ password: process.env.BDDpsw }, function (err, pass, salt, hash) {
  if (err) throw err;

  var sql = "INSERT INTO students (name, email, psw, pswsalt, enabled) VALUES ('Valentin', 'valentinmail', '"+hash+"','"+salt+"', 1)";
  connection.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
  });
}); */

// fonction d'authentification
function authenticate(studentID, pass, fn) {
  if (!module.parent) console.log('Authentification %s:%s', studentID, pass);
  // on essaye d'obtenir l'étudiant depuis la bdd
  connection.query(
    'SELECT * FROM `students` WHERE `studentID` = "' + studentID + '"',
    function (err, results, fields) {

      if (err) {
        return fr(err) // une erreur et on arrête tout
      }

      student = results[0] // on prend l'unique résultat

      // on vérifie que l'étudiant est bien dans la bdd sinon ça dégage
      if (!student) return fn(null, null)
      
      // on vérifie le mot de passe 
      hash({ password: pass, salt: student.pswsalt }, function (err, pass, salt, hash) {
        if (err) return fn(err);
        if (hash === student.psw) return fn(null, student)
        fn(null, null)
      });

    })
}

// fonction de restriction d'accès
function restrict(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    req.session.error = 'Accès interdit!';
    res.redirect('/');
  }
}

/* ---- ROUTING ---- */

app.get('/', function (req, res) {
  res.render('index');
});

app.get('/logout', function (req, res) {
  // destroy the user's session to log them out
  // will be re-created next request
  req.session.destroy(function () {
    res.redirect('/');
  });
});

app.post('/', function (req, res, next) {
  authenticate(req.body.id, req.body.password, function (err, user) {
    if (err) return next(err)

    console.log(req.body);

    console.log(user);
    if (user) {
      req.session.regenerate(function () {
        req.session.user = user;
        req.session.success = 'Bienvenue sur le site ' + user.name
        res.redirect('/home');
      });
    } else {
      req.session.error = `L'authentification a échouée, veuillez vérifier votre identifiant et votre mot de passe.`;
      res.redirect('/');
    }
  });
});

app.get('/home', restrict, function (req, res) {
  res.render('home')
})

/* istanbul ignore next */
if (!module.parent) {
  app.listen(3000);
  console.log('Express started on port 3000');
}