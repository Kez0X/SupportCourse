# Creer un algorithme dans lequel vous demandez un nombre entier à l'utilisateur puis vous devez renvoyer le nombre si il est supérieur à 0, sinon si il est inférieur à 0 alors vous devrez renvoyer ce nombre moins 3 et sinon vous devrez renvoyer 0.

nombres = int(input("Veuillez entrez un nombre"))
if nombres > 0:
    rep = nombres
elif nombres < 0:
    rep = nombres -3
else:
    rep = 0
return rep