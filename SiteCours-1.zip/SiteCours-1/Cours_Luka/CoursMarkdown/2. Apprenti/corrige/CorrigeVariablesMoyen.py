# Définir une variable mot à un mot sous forme de chaine de caractère et utiliser une boucle qui permet d'ajouter 8 fois la lettre r.

mot="quelconque" # On définit un mot aléatoirement, on aurait aussi pu le demander à l'utilisateur de cette manière mot = str(input("Veuillez rentrer un mot"))
for valeurs in range(8): # On va répéter 8 fois la boucle
    mot = mot + "r" # A chaque fois que la boucle va se répéter la variable mot va se répéter.
print(mot) # Il ne nous reste plus qu'à afficher le mot modifié
