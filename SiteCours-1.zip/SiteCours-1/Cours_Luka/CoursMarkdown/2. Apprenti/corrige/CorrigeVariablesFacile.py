#Demander à l'utilisateur un nombre réel pour la variable Valeur et l'afficher.

Valeur = float(input("Veuillez entrer un nombre réel :")) # Ici on utilise float car c'est un nombre réel
print(Valeur) # On affiche la variable valeur qui a pris la valeur rentrer par l'utilisateur
