def indices(element, entiers):
    """
    Entrée : element : l'élément rechercher, entiers : une liste de nombres
    Sortie : Une liste avec les indices où est l'élément dans la liste entiers
    Fonction : Permet de chercher et trouver les indices où se trouve le nombre élément
    """
    ListeIndices=[] # On initialise la liste où va se trouver les indices
    for indices in range(len(entiers)): # On parcours les indices de la liste car on veut récupérer les indices
        if entiers[indices]==element: # On regarde si le nombre à l'indice indice correspond à l'élément
            ListeIndices.append(indices) # Si oui alors on ajoute son indice dans notre liste ListeIndices
    return ListeIndices # On retourne ListeIndices


# tests

assert indices(3, [3, 2, 1, 3, 2, 1]) == [0, 3]
assert indices(4, [1, 2, 3]) == []
assert indices(1, [1, 1, 1, 1]) == [0, 1, 2, 3]
assert indices(5, [0, 0, 5]) == [2]