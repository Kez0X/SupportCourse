# Creer un algorithme ou vous demandez un mot à l'utilisateur puis si le mot a moins de 5 lettres vous renvoyez 'le mot est trop court' puis si le mot a moins de 10 lettres mais plus de 5 lettres alors vous renverez 'le mot est moyen' sinon vous renverez 'le mot est d'une longueur suffisante'.

mot = str(input("Veuillez rentrer un mot en tant que chaine de caractère :"))
if len(mot)<5:
    rep = 'le mot est trop court'
elif len(mot)<10 and len(mot)>5:
    rep = 'le mot est moyen'
else:
    rep = "le mot est d'une longueur suffisante"
return rep