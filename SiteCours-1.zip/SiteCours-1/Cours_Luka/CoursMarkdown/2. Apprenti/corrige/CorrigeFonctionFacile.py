###Facile

def CalculLocation(PrixHeure, NbHeure):
    return PrixHeure * NbHeure