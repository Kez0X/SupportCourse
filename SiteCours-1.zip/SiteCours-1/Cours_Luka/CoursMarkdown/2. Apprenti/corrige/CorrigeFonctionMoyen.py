###Moyen

def Moyenne(ListeNotes):
    """
    Entrée : ListeNotes : une liste de notes
    Sortie : La moyenne de ces notes
    Fonction : Calcul la moyenne des notes de la liste ListeNotes
    """
    AdditionNotes = 0
    nbNotes= 0
    for notes in ListeNotes:
        AdditionNotes = AdditionNotes +notes
        nbNotes = nbNotes + 1
    return AdditionNotes/nbNotes