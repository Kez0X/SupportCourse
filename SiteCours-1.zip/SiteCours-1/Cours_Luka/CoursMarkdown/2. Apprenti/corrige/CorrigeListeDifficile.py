def indice_min(nombres):
    """
    Entrée : nombres : uneliste non vide
    Sortie : La première occurence du minimum
    Fonction : Trouve la première occurence du minimum dans la liste nombres
    """
    min=nombres[0] # On initialise le minimum au premier élément de la liste
    PremiereOccurrences=0 # On initialise la Première occurence au premier indice de la liste
    ListeOccurences=[] # On initialise la liste des occurrences
    for occurences in range(len(nombres)): # On utilise une boucle for car on va aller jusqu'à la fin de la liste pour être sûr qu'il n'y a pas encore de plus petit nombre
        if nombres[occurences]<min: # Si le nombre actuel est plus petit que le minimum alors
            min=nombres[occurences] # le minimum devient ce nombre
            ListeOccurences=[occurences] # On initialise une nouvelle liste avec l'occurence actuel cette fois ci 
            PremiereOccurrences = ListeOccurences[0] # La première occurence sera le premier élément de la liste des occurences
        elif nombres[occurences] == min: # Si le nombre actuel est égal au minimum alors c'est la deuxième fois qu'on le croise
            ListeOccurences.append(occurences) # On ajoute donc son occurence à notre liste et on ne la réinitialise pas
    return PremiereOccurrences # On retourne la première occurence

# Les deux fonctions sont justes

def indice_min_bis(nombres):
    """
    Entrée : nombres : uneliste non vide
    Sortie : La première occurence du minimum
    Fonction : Trouve la première occurence du minimum dans la liste nombres
    """
    min=nombres[0] # On initialise le minimum au premier élément de la liste
    PremiereOccurrences=0 # On initialise la Première occurence au premier indice de la liste
    for occurences in range(len(nombres)): # On utilise une boucle for car on va aller jusqu'à la fin de la liste pour être sûr qu'il n'y a pas encore de plus petit nombre
        if nombres[occurences]<min: # Si le nombre actuel est plus petit que le minimum alors
            min=nombres[occurences] # le minimum devient ce nombre
            PremiereOccurrences = occurences # La première occurence sera l'occurence qu'on récupère
    return PremiereOccurrences # On retourne la première occurence



# tests

assert indice_min([5]) == 0
assert indice_min([2, 4, 1, 1]) == 2
assert indice_min([5, 3, 2, 5, 2]) == 2

assert indice_min_bis([5]) == 0
assert indice_min_bis([2, 4, 1, 1]) == 2
assert indice_min_bis([5, 3, 2, 5, 2]) == 2