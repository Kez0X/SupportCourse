def maximum(nombres):
    """
    Entrée : nombres : une liste non vide
    Sortie : le plus grand nombre de la liste
    Fonction : Trouve le maximum dans la liste
    """
    max = nombres[0] # On initialise le maximum au premier nombre
    for elements in nombres: # On parcourt la liste
        if elements>max: # On regarde si l'element actuel est plus grand que le maximum 
            max=elements # Si oui alors il devient le nouveau maximum
    return max # On retourne le maximum


# Tests
assert maximum([98, 12, 104, 23, 131, 9]) == 131
assert maximum([-27, 24, -3, 15]) == 24