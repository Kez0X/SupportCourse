# Demander à l'utilisateur une variable nombre qui prend en paramètre un entier. Puis rajouter 2 à chaque fois dans une boucle qui va se répéter 10 fois. Puis rajouter 10 et diviser par 2. Et enfin renvoyer la variable.

variable = int(input("Veuillez entrer un nombre entier :")) # On demande à l'utilisateur un entier
for valeurs in range(10): # On creer une boucle qui va se répéter 10 fois
    variable = variable + 2 # A chaque fois on ajoute 2 à la variable
variable = variable + 10 # On ajoute 10 à la variable
variable = variable /2 # On la divise par 2
print(variable) # On la retourne
