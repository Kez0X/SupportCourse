import random

def Pile():
    """
        Crée une pile vide
        Entrée : aucune
        Sortie : Pile vide
    """
    return {}


def Empiler(p, elt):
    """
        Empile l'élément elt dans la Pile p.
        Entrées :
                * p : une Pile
                * elt : élément à empiler
        Sortie : aucune
    """
    p[len(p)+1] = elt

def Depiler(p):
    """
        Dépile le dernier élément de la pile p et le renvoie.
        Entrée : une Pile p non vide
        Sortie : l'élément dépiler
    """
    rep = p[len(p)]
    del p[len(p)]
    return rep

def PileVide(p):
    """
        Vérifie si une Pile est vide
        Entrée : une Pile p
        Sortie : un booléen (True si la Pile est vide, False sinon)
    """
    return len(p) == 0