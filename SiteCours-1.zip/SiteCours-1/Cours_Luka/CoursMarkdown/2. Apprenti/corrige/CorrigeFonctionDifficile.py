### Difficile

def denivele_positif(ListeAltitudes):
    """
    Entrée : ListeAltitudes : la liste des Altitudes
    Sortie : le denivelé total positif
    Fonction : permet de calculer le dénivelé total positif à partir de la liste des altitudes
    """
    denivpos=0
    for indice in range(len(ListeAltitudes)-1):
        rep=ListeAltitudes[indice+1]-ListeAltitudes[indice]
        if rep>0:
            denivpos=denivpos+rep
    return denivpos