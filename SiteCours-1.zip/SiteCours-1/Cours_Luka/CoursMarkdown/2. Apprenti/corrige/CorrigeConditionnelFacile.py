# Creer un algorithme dans lequel vous demandez un nombre entier à l'utilisateur puis vous devrez renvoyer True si le nombre est inférieur à 1 et False si il est supérieur ou égal à 1.

nombre = int(input("Veuillez rentrer un nombre :"))
if nombre < 1:
    rep = True
else :
    rep = False
return rep