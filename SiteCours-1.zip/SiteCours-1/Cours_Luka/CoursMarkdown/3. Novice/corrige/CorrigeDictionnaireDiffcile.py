def occurence_caractere(phrase):
    """
    Entrée : Une phrase : str
    Sortie : Un dictionnaire avec le nombre d'occurences de chaque caractères
    Fonction : compte le nombre d'occurences de chaque lettres dans la phrase et la renvoie sous forme de dictionnaire
    """
    dico ={}
    for lettres in phrase:
        if lettres not in dico:
            dico[lettres]=1
        else:
            dico[lettres]+=1
    return dico