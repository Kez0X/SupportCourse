DicoNotes ={"Jean": 12, "Kevin": 15, "Greg": 16, "Lila": 10, "Ove":18}

def MoyenneDico(DicoNotes, DicoNouvelleNote):
    """
    Entrée : DicoNotes : dictionnaire des anciennes notes et DicoNouvelleNotes : dictionnaire des nouvelles notes
    Sortie : DicoNotes : dictionnaire avec les nouvelles moyennes de notes
    Fonction : Sert à récupérer les nouvelles notes et à faire la moyenne avec les anciennes notes
    """
    for noms in DicoNouvelleNote:
        for NomsEleves in DicoNotes:
            if noms == NomsEleves:
                DicoNotes[NomsEleves]=(DicoNotes[NomsEleves]+DicoNouvelleNotes[NomsEleves])/2
    return DicoNotes

    assert(MoyenneDico({"Jean": 12, "Kevin": 15, "Greg": 16, "Lila": 10, "Ove":18},{"Jean": 13, "Kevin": 18, "Greg": 15, "Lila": 18, "Ove":6}))=={"Jean": 12.5, "Kevin": 16.5, "Greg": 15.5, "Lila": 14, "Ove":12}

