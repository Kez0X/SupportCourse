# Ordre des formations + Stratégies marketing
---
## Python

*Eleves depuis une dizaine d'heures ou 70€ la formation complète avec interdiction de publier mais il peut garder tous les dossiers à vie. Formation gratuite jusqu'aux booléens (pas la partie des nombres binaires)*

//Prévu pour le 30 mai !//

Promotions aux 2 Premières semaines de lancement **Spécial lancement**: - 20%

Promotions au 15 septembre jusqu'au 22 septembre **Spécial Rentrée** : - 10%

Promotions au black friday **Spécial Black Friday** : - 15%

Promotions au 20 décembre jusqu'au 23 décembre **Spécial Noël** : - 10%

Promotions au 5 février jusqu'au 12 février **Spécial Bac** : - 10% 

Promotions au 30 juin jusqu'au 7 juillet **Spécial Vacances** : - 10%

|Objectif 4200 lignes|Réalisation -- lignes| Statut : En cours

0. Introduction 1 leçon

* Introduction à Python |Objectif 100 lignes|Réalisation 116 lignes| Statut : Fini

1. Apprenti 6 leçons

* Variables |Objectif 100 lignes|Réalisation 130 lignes| Statut : Fini
* Booléens & Nombres binaires positif |Objectif 300 lignes|Réalisation 392 lignes| Statut : Fini
* Conditionnel |Objectif 150 lignes|Réalisation 136 lignes| Statut : Fini
* Boucles |Objectif 200 lignes|Réalisation 317 lignes| Statut : Fini
* Fonctions |Objectif 200 lignes|Réalisation -- lignes| Statut : En cours
* Listes |Objectif 150 lignes|Réalisation -- lignes| Statut : En cours


2. Novice 7 leçons

* Dictionnaires |Objectif 200 lignes|Réalisation -- lignes| Statut : En cours
* Nombres binaires négatifs |Objectif 150 lignes|Réalisation -- lignes| Statut : En cours
* Les Tris |Objectif 200 lignes|Réalisation -- lignes| Statut : En cours
* Les coûts |Objectif 100 lignes|Réalisation -- lignes| Statut : En cours
* Piles |Objectif 150 lignes|Réalisation -- lignes| Statut : En cours
* Files |Objectif 150 lignes|Réalisation -- lignes| Statut : En cours
* Recursivité |Objectif 200 lignes|Réalisation -- lignes| Statut : En cours

3. Avancé 4 leçons

* La turtle |Objectif 150 lignes|Réalisation -- lignes| Statut : En cours
* Classes |Objectif 200 lignes|Réalisation -- lignes| Statut : En cours
* Arbres Binaire de Recherches |Objectif 250 lignes|Réalisation -- lignes| Statut : En cours
* Lier les fichiers CSV |Objectif 250 lignes|Réalisation -- lignes| Statut : En cours

4. Développeur 3 leçons

* Les requêtes serveurs en python |Objectif 300 lignes|Réalisation -- lignes| Statut : En cours
* Les Algorithmes de recommandations |Objectif 300 lignes|Réalisation -- lignes| Statut : En cours
* Creer un jeu 2D en python |Objectif 600 lignes|Réalisation -- lignes| Statut : En cours

---

## SQL

*Eleves depuis une dizaine d'heures ou 60€ la formation complète avec interdiction de publier mais il peut garder tous les dossiers à vie. Formation gratuite jusqu'aux BDD*

//Prévu pour le 15 juillet !//

Promotions aux 2 Premières semaines de lancement **Spécial lancement**: - 20%

Promotions au 30 septembre jusqu'au 7 octobre **Spécial Rentrée** : - 10%

Promotions au black friday **Spécial Black Friday** : - 15%

Promotions au 20 décembre jusqu'au 23 décembre **Spécial Noël** : - 10%

Promotions au 5 février jusqu'au 12 février **Spécial Bac** : - 10% 

Promotions au 30 juin jusqu'au 7 juillet **Spécial Vacances** : - 10%

|Objectif 3000 lignes|Réalisation -- lignes| Statut : Non débuté

0. Introduction

* Introduction à SQL |Objectif 150 lignes|Réalisation -- lignes| Statut : Non débuté

1. Apprenti

* Les bases de données |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté
* Creer une table |Objectif 200 lignes|Réalisation -- lignes| Statut : Non débuté
* Les requêtes de créations de tables |Objectif 150 lignes|Réalisation -- lignes| Statut : Non débuté
* Les requêtes serveurs simples |Objectif 200 lignes|Réalisation -- lignes| Statut : Non débuté


2. Novice

* Les requêtes de modifications |Objectif 300 lignes|Réalisation -- lignes| Statut : Non débuté
* Lier sa table SQL à son projet python |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté

3. A venir |Objectif 1200 lignes|Réalisation -- lignes| Statut : Non débuté

---

## Le réseau

*Eleves depuis une dizaine d'heures ou 80€ la formation complète avec interdiction de publier mais il peut garder tous les dossiers à vie. Formation gratuite jusqu'aux bases de BASH*

//Prévu pour le 5 septembre !//

Promotions aux 2 Premières semaines de lancement **Spécial lancement**: - 20%

Promotions au 30 octobre jusqu'au 7 novembre **Spécial Rentrée** : - 10%

Promotions au black friday **Spécial Black Friday** : - 15%

Promotions au 20 décembre jusqu'au 23 décembre **Spécial Noël** : - 10%

Promotions au 5 février jusqu'au 12 février **Spécial Bac** : - 10% 

Promotions au 30 juin jusqu'au 7 juillet **Spécial Vacances** : - 10%


|Objectif 5000 lignes|Réalisation -- lignes| Statut : Non débuté

0. Introduction

* Introduction aux réseaux |Objectif 200 lignes|Réalisation -- lignes| Statut : Non débuté

1. Apprenti

* Les bases de BASH |Objectif 300 lignes|Réalisation -- lignes| Statut : Non débuté
* Le routage |Objectif 300 lignes|Réalisation -- lignes| Statut : Non débuté
* Protocole TCP/IP |Objectif 300 lignes|Réalisation -- lignes| Statut : Non débuté

2. Novice

* Protocole RIP/ OSPF |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté
* Protocole ARP |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté
* Les enjeux |Objectif 150 lignes|Réalisation -- lignes| Statut : Non débuté

3. Avancé

* BASH avancé |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté
* Le chiffrement symétrique |Objectif 300 lignes|Réalisation -- lignes| Statut : Non débuté
* Le chiffrement asymétrique |Objectif 300 lignes|Réalisation -- lignes| Statut : Non débuté

4. Ingénieur SFR

* Brancher une box internet |Objectif 100 lignes|Réalisation -- lignes| Statut : Non débuté
* Se protéger des attaques DDOS |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté
* Protéger sa connexion |Objectif 500 lignes|Réalisation -- lignes| Statut : Non débuté
* A venir |Objectif 950 lignes|Réalisation -- lignes| Statut : Non débuté

## Linux

|Objectif 1500 lignes|Réalisation -- lignes| Statut : Non débuté

*Formation gratuite*

//Prévu pour le 15 juin !//

0. Introduction

* Introduction à Linux |Objectif 250 lignes|Réalisation -- lignes| Statut : Non débuté

1. Apprenti

* L'arborescence |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté
* Les processus |Objectif 200 lignes|Réalisation -- lignes| Statut : Non débuté
* Les commandes de bases |Objectif 250 lignes|Réalisation -- lignes| Statut : Non débuté

2. Novice

* A venir |Objectif 400 lignes|Réalisation -- lignes| Statut : Non débuté

